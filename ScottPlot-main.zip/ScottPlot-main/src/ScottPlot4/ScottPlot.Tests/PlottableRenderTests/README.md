﻿# Render Tests for Plottables

These tests analyze bitmap pixels to confirm style customizations of plottables are working. 
Because Bitmaps are involved and this process is slow, these tests may one day be split into a separate 
file containing only acceptance tests.