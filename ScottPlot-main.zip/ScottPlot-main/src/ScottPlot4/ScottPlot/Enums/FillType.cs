﻿namespace ScottPlot
{
    public enum FillType
    {
        NoFill,
        FillAbove,
        FillBelow,
        FillAboveAndBelow
    }
}
