﻿namespace ScottPlot
{
    public enum HorizontalAlignment
    {
        Left,
        Right,
        Center
    }
}
