﻿namespace ScottPlot
{
    public enum Orientation
    {
        Horizontal,
        Vertical
    }
}
