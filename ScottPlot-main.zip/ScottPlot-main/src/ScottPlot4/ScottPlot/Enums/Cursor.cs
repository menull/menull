﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ScottPlot
{
    public enum Cursor
    {
        Arrow,
        Crosshair,
        Hand,
        WE,
        NS,
        All,
        Question
    }
}
