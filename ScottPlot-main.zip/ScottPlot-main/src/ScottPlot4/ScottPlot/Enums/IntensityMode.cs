﻿namespace ScottPlot
{
    public enum IntensityMode
    {
        Gaussian,
        Density
    }
}
